import { Component } from "@angular/core";
import { Product } from "./product";
import { ProductService } from "./product.service";

@Component({
    selector: "app-DI",
    templateUrl:"./product.component.html"
})

export class ProductComponent{
    product: Product;

    constructor(public prodService: ProductService){
        console.log("Service is Injected");
        this.product=this.prodService.getProduct();
    }
}