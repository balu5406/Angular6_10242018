import { Injectable } from "@angular/core";
import { Product } from "./product";

@Injectable()
export class ProductService{
    getProduct(): Product {
        return new Product (101, "iPhone8", "THe latest iPhone, 9-inch screen", 1200.00);
    }
}