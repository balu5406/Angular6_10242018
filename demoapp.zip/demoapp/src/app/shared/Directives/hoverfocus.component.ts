import { Directive, HostBinding, HostListener, Component } from "@angular/core";

@Directive( { selector: '.hover-focus' } )
export class HoverFocusDirective{
    @HostBinding("style.background-color") backgroundcolor: string;
    @HostBinding("style.color") clr: string;
    @HostBinding("style.font-size") fontSize: string;

    @HostListener("mouseover") onHover(){
        this.backgroundcolor = 'red';
        this.clr='yellow';
        this.fontSize='40px';
    }

    @HostListener("mouseout") onLeave(){
        this.backgroundcolor = 'blue';
        this.clr='pink';
        this.fontSize='inherit';
    }

}

