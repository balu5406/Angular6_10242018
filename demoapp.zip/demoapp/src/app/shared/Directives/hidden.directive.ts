import { Directive, ElementRef, Input, Renderer } from "@angular/core";

@Directive({ 
    selector: '[myHidden]' 
})

export class HiddenDirective{
    constructor (public el: ElementRef, public render: Renderer){
        
    }

    @Input()
    myHidden: boolean;

    ngOnInit(){
        console.log(this.myHidden);

        if(this.myHidden){
            console.log(this.el.nativeElement);

            this.render.setElementStyle(this.el.nativeElement, 'display', 'none');
        }
    }
}