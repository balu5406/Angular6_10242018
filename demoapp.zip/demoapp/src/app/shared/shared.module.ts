import { NgModule } from "@angular/core";

import { HiddenDirective  } from './Directives/hidden.directive'
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { TestComponent } from "./test.component";
import { HoverFocusDirective } from "./Directives/hoverfocus.component";
import { TemperaturePipe } from "./temperature.pipe";


@NgModule({
    imports: [ CommonModule, FormsModule ],
    declarations: [ HiddenDirective, TestComponent, HoverFocusDirective, TemperaturePipe ],
    providers: [],
    exports: [ HiddenDirective, TestComponent, HoverFocusDirective, TemperaturePipe ]    
})

export class SharedModule{

}