import { Component } from "@angular/core";

@Component({
    selector:"app-viewchildComp",
    styles: [ '.text{ margin-bottom:10px; color:red }' ],
    template:`
        <div>
            <h2>Child Component</h2>
            <div class="text">
                <span [hidden]="!shwTxt"> I am visible now! Thanks to {{visibilitySrc}} </span>
            </div>
            <div>
                <button (click)="toggleVisibility('Child Component')"> Show/Hide Text </button>
            </div>
        </div>
    `
})

export class ViewChildComponent{
    shwTxt:boolean=false;
    visibilitySrc:string="";

    toggleVisibility(src:any){
        this.shwTxt = !this.shwTxt;
        this.visibilitySrc = src;
    }
}