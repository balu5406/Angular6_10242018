import { Component, ViewChild } from "@angular/core";
import { ViewChildComponent } from "./viewchild.component";

@Component({
    selector: "app-viewchild",
    template: `
        <div>
            <h1>Parent Component</h1>
            <button (click)="showHideText()"> Show / Hilde Child Component Text </button>
        
            <div class="container" style="background-color:yellow">
                <app-viewchildComp></app-viewchildComp>
            </div>
        </div>
    `
})

export class ViewChildParentComponent{
    @ViewChild(ViewChildComponent) private chlComp: ViewChildComponent;

    showHideText(){
        this.chlComp.toggleVisibility('Parnet Component');
    }
}