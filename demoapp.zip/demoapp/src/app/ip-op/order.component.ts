import { Component, Input } from "@angular/core";

@Component({
    selector: "app-orderProc",
    template: `
        <h2 class="bg-primary" >Stock Info</h2>
        <h2 class="text-danger container " >
            Buying of {{ Qnt }} shares of {{ stockSymb }}
        </h2>

        Company name is : <input type="text" [(ngModel)]="stockSymb" />

        <app-sms [stock]="stockSymb"></app-sms>
    `
})

export class OrderComponent {

    @Input()
    Qnt:number;

    @Input()
    stockSymb:string;
}