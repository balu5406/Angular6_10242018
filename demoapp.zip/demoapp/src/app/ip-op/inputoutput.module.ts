import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { StockComponent } from "./inputbinding";
import { OrderComponent } from "./order.component";
import { TimerComponent } from "./timer.component";
import { SMSComponent } from "./sms.component";
import { OutputComponent, PriceQuoterComponent, MailComponent } from "./outputbinding";

@NgModule({
    imports : [ CommonModule, FormsModule ],
    declarations: [ StockComponent, OrderComponent, TimerComponent, SMSComponent
        , OutputComponent, PriceQuoterComponent, MailComponent ],
    exports: [ StockComponent, OutputComponent ]
})

export class IOModule{

}