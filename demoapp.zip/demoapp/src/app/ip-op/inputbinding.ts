import { Component } from "@angular/core";

@Component({
    selector: "app-stock",
    template: `
        <div class="text-left">
            <h1 class="bg-danger">Stock Exchange</h1>
            <input type="text"  placeholder="Enter stock (e.g : verizon)" (change)="onIpEvnt($event)"/>
            <br/>   
            
            <div>Stock Info :{{stock}}</div>

            <app-orderProc [stockSymb]="stock" Qnt="100">
            </app-orderProc>
        </div>

        <app-timer></app-timer>
    `    
})

export class StockComponent {
    stock:any;

    onIpEvnt( {target}:any ): void {
        this.stock=target.value;
    }
}