import { Component, EventEmitter, Output, Input } from "@angular/core";

export interface iPriceQuote{
    stockSym: string;
    lastPrice: number;
}

//Price Quoter component
@Component({
    selector: "app-priceQuoter",
    template: `
        <h3 class="well text-danger" >Child Price Quote Component: {{ stockSymbol }}  {{ price | currency:'USD' }}</h3>
    `
    
})

export class PriceQuoterComponent{
    @Output()
    lastPriceEvent: EventEmitter<iPriceQuote> = new EventEmitter();
    stockSymbol:string = "Verizon";
    price:number;

    constructor(){
        window.setInterval(() => {
            let priceQuote: iPriceQuote={
                stockSym: this.stockSymbol,
                lastPrice: 100 * Math.random()
            };
            this.price=priceQuote.lastPrice;
            this.lastPriceEvent.emit(priceQuote) ;
        }, 2000);
    }

}

// app-Event component which is parent to price quoter and mail components
@Component({
    selector: "app-event",
    template: `
        <div class="container">
            <h1 class='text-success'>Parent Component received: {{ stockSymbol }} - {{ price | currency:'USD' }} </h1>

            <app-priceQuoter (lastPriceEvent)="priceQuoteHandler($event)" ></app-priceQuoter>

            <app-mail [info]="stockInfo"></app-mail>
        </div>
    `
})

export class OutputComponent{
    stockSymbol: string;
    price: number;
    stockInfo:iPriceQuote = { 'stockSym':' ', 'lastPrice':0 };

    priceQuoteHandler(event: iPriceQuote) {
        this.stockSymbol = event.stockSym;
        this.price = event.lastPrice;
        this.stockInfo = {'stockSym':event.stockSym, 'lastPrice':event.lastPrice};
    }
}

// Mail Component (Child)
@Component({
    selector: 'app-mail',
    template: `
        <div class='container'>
            <h3 class='text-primary'>Sent notification about {{info.stockSym}} and Stock value {{info.lastPrice | currency:'USD'}} successfully.
            </h3>
        </div>
    `
})
export class  MailComponent {
    @Input() 
    info:iPriceQuote;
}//end