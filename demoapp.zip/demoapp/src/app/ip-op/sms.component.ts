import { Component, Input } from "@angular/core";

@Component({
    selector: "app-sms",
    template: `
        <h3 class="bg-warning" > Stock information from child SMS component </h3>
        <h2 class="text-success container"> Sent SMS to client about : {{ stock }} </h2>
    `
})

export class SMSComponent{
    @Input()
    stock:any
}