import { Injectable, ComponentFactoryResolver, Inject } from "@angular/core";

import { DynamicComponent } from "./dynamic.component"
import { ViewContainerRef } from "@angular/core"

@Injectable()
export class ServiceLoader{
    factoryResolver: ComponentFactoryResolver;
    rootViewContainer: ViewContainerRef;

    constructor(@Inject(ComponentFactoryResolver) factryReslvr ){
        this.factoryResolver = factryReslvr;
    }

    setRootViewContainerRef( ViewContainerRef){
        this.rootViewContainer=ViewContainerRef;
    }

    addDynamicComponent(){
        const factory = this.factoryResolver.resolveComponentFactory(DynamicComponent);

        const component = factory.create(this.rootViewContainer.parentInjector);

        this.rootViewContainer.insert(component.hostView);
    }

}