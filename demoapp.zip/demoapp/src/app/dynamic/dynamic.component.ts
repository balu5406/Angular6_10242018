import { Component } from "@angular/core";

@Component({
    template:`
        <h3 style="text-alig:center; bakground:pink" >eMail: sdkjlbnsdfg@slkfnsd.com </h3>
    `
})

export class DynamicComponent {

}