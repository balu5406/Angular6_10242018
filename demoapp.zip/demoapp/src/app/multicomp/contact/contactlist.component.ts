import { Component, OnInit } from "@angular/core";
import { ContactService } from "../services/contacts.service";
import { Contact } from "../services/contact";
import { error } from "@angular/compiler/src/util";

@Component({
    selector: 'app-multicomp',
    providers: [ContactService],
    templateUrl:'./contactlist.component.html'
})

export class ContactListComponent implements OnInit{
    
    public contacts: Contact[];
    public slctContact: any = {};
    status: boolean=true;    

    constructor(public _contactService: ContactService){
        console.log("Service Injected");
    }

    ngOnInit() {
        console.log("ngOnInit Fired and contacts injected");
        this.getContactDetails();
    }

    getContactDetails(){
        this._contactService.getContacts().then((result: Contact[]) => {this.contacts=result} )
            , ((error: any) => { this.status = false } );
    }

    getSelectedContact(contact: Contact){
        console.log("selected contact name " + contact.name)
        this.slctContact = contact
    }


}