import { Injectable } from "@angular/core";
import{ CONTACTS } from "./mock-contacts";

@Injectable()
export class ContactService{
    err:boolean = false;

    getContacts(){
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                if(this.err){
                    reject("Sorry... can not fetch Contacts");                    
                }
                else {
                    resolve(CONTACTS);
                }
            }, 1000 );
        } );
    }
}