import { Contact } from "./contact";

export const CONTACTS: Contact[] = [
    {name: "Murthy", email: "123@gmail.com", phone: "245424"},
    {name: "Krishna", email: "456@gmail.com", phone: "245424"},
    {name: "Bala", email: "xyz@gmail.com", phone: "245424"}
]