import { Component, OnInit } from "@angular/core";
import { BrowserModule } from '@angular/platform-browser';
import { FormGroup, FormControl, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserInfo } from "./userinfo";
import { LoginService } from "./login.service";

@Component({
    selector: 'app-logInValidation',
    templateUrl:'./login.component.html',
    styles: [ './styles.component.css' ],
    providers: [ LoginService ]
})

export class LoginValidationComponent implements OnInit {
    user: UserInfo;
    status:boolean;
    msg:string;
    form:any;

    constructor( private lgInSrvc: LoginService ){
        // this.loginsvc = lgInSrvc;
    }

    ngOnInit() {
        this.form = new FormGroup({
          username: new FormControl('', Validators.compose([
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(50),
            //Validators.pattern('[\\w\\-\\s\\  /]') 
          ])
          ),
          password: new FormControl('', this.pwdValidator),
          country: new FormControl('')
        })
      }
      
      //Custom validator
      pwdValidator(control) {
        //observe HTML  (ngValid, ngInvalid, ngDirty, ngPrestine....)
        if (control.value.length > 2) {
          this.form.isValid=true;
          return { 'password': true }
        }
      }
      onSubmit(user: any) {
        let u: UserInfo = { uName: user.username, pwd: user.password }
    
        if (this.lgInSrvc.CheckUser(u)) {
          this.status = true;
          this.msg = "Welcome to Murthy Infotek";
        } else {
          this.status = false;
          this.msg = "Sorry... invalid user name or password";
        }
      }
      usernameChanged(oldValue, newValue) {
        console.log( 'User Name Changed ' + newValue);
      }
}