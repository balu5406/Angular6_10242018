export interface UserInfo{
    uName: string,
    pwd: string
}