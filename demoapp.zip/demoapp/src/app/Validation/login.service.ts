import { Injectable } from "@angular/core";
import { UserInfo } from "./userinfo";
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class LoginService{
    CheckUser(user: UserInfo):boolean{
        console.log('Started Validation : ' + user.uName + '  ' + user.pwd );
        if(user.uName == 'murthy' && user.pwd == 'hi' ){
            console.log('Validated');
            return true;            
        }
        else {
            console.log('Not Validated');
            return false;
        }
    }
}