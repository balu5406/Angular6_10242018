import { Component, Inject, ViewContainerRef, OnInit, OnDestroy } from '@angular/core';
import { ServiceLoader } from './dynamic/serviceLoader';
import { Subscription } from 'rxjs';
import { MessageService  } from './intercom/services/index';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

/* export class AppComponent {
  title ='app';
  constructor(public servcLdr: ServiceLoader, @Inject(ViewContainerRef) viewContainerRef ){
    servcLdr.setRootViewContainerRef(viewContainerRef);
    servcLdr.addDynamicComponent();
  }

} */

export class AppComponent implements OnInit, OnDestroy {
  message: any;
  subscription: Subscription;

  constructor(private messageService: MessageService) {
      console.log("I am subscriber")
  }

  ngOnInit(){
  this.subscription = 
  this.messageService.getMessage().subscribe
        ((message:any) => { this.message = message; });
  }
  
  ngOnDestroy() {
      // unsubscribe to ensure no memory leaks
      this.subscription.unsubscribe();
  }
}