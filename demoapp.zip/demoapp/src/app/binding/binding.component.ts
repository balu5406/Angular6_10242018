import { Component, ViewEncapsulation, OnInit } from '@angular/core';

@Component({
  selector: 'app-binding',
  templateUrl: './binding.component.html',
  // styleUrls: ['./binding.component.css']
  styles: [`
    h3 {
      text-decoration: underline;    
    }

    h1 {
        color: blue;
    }

    .myclr {
        background-color: lightgreen;
    }
  `],
  encapsulation: ViewEncapsulation.None

})
export class BindingComponent implements OnInit {

  clk:boolean=false;
  titleStyle:string='blue';
  btnStatus:boolean=false;

  //JSON Collection
  items: any=[
    {name: 'Kendo UI'},
    {name: 'Ext JS'},
    {name: 'Angular JS'},
    {name: 'Ember JS'}
  ];

  // Property and field
  public clkItem:any={name: ''};

  onItmClk(item: any){
    this.clkItem=item;
    this.clk=true;
  }

  Save(event:any):void{
    alert("OK... Thanks for enrolling");
    this.btnStatus=true;
  }

  constructor() { }

  ngOnInit() {
  }

}
