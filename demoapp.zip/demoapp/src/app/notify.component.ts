import { OnInit, OnDestroy, Component } from "@angular/core";
import { Subscription } from "rxjs";
import { MessageService } from "./intercom/services";

@Component({
    selector:'app-notify',
    template:`
    <div class="jumbotron">
    <div class="container text-center bg-primary">
        <div class="row">
            <div class="col-sm-8 offset-sm-2">
             <h3>I am Notifier component</h3>
                <div *ngIf="msg" class="alert alert-success">
                {{msg.text}}</div>
            </div>
        </div>
    </div>
</div>
    `
})

export class NotifyComponent implements OnInit, OnDestroy{
    msg: any;
    compSubscription: Subscription;

    constructor(private msgSrvc: MessageService){
        console.log("I am Notifier");
    }

    ngOnInit(){
        this.compSubscription = this.msgSrvc.getMessage().subscribe( (message: any) => { this.msg = message; } );
    }

    ngOnDestroy(){
        this.compSubscription.unsubscribe();
    }
}