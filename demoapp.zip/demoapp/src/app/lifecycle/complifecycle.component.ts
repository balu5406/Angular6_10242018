import { Component, Input, OnInit, OnChanges, DoCheck, OnDestroy
        , ChangeDetectorRef, SimpleChanges } from "@angular/core";

@Component({
    selector: "app-lifecycle",
    template: `
        <h1 class="container">
            Google Search : <input type="text" [(ngModel)] = "srch" />
        </h1>

        <app-child [search]="srch"></app-child>
    `
})

export class CompLifeCycleComponent {
    srch:string = "Computers";
}

//Child component
@Component({
    selector: "app-child",
    template: `
        <h1 class="text-danger container" id="txt" >Search Text</h1>
        <div>
            <h3 class="text-primary container">{{ search }}</h3>
        </div>
    `
})

export class ChildComponent implements OnInit, OnChanges, DoCheck, OnDestroy{
    chged:boolean=false;

    @Input()
    search:string;

    constructor(public cd: ChangeDetectorRef){
        // only inject services as dependencies using DI
        console.log(`Constructor : ${this.search} `)
        this.chged=false;
        this.cd.detach();

        // it renders after 5 secs
        setTimeout(() => {
            this.cd.reattach();
        }, 5000);
    }

    ngOnInit(){
        console.log(`ngOnIt : ${this.search} `)
    }

    ngOnChanges(chgs: SimpleChanges):void {
        console.log(`ngOnChanges : ${this.search} `)
    }

    ngDoCheck(){
        console.log("ngDoCheck :--> Change detection strategy ")

        /* if(this.search.length == 10){
            // Ajax call to server and get data
            this.cd.detectChanges();
        }    */      
        
        // this.cd.checkNoChanges();
    }    

    ngAfterViewChecked(){
        console.log("Under ngAfterViewChecked fetching the h1 tag Text :--> " + document.getElementById("txt").innerText );
        //$("#div1").fadeIn();
    }

    ngOnDestroy(){
        console.log("Component Destroy")
    }
}