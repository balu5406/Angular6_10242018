import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { BindingModule } from './binding/binding.module';
import { IOModule } from './ip-op/inputoutput.module';
import { OutputComponent } from './ip-op/outputbinding';
import { ViewChildParentComponent } from './viewchilddemo/viewchildparent.component';
import { ViewChildComponent } from './viewchilddemo/viewchild.component';
import { DIModule } from './di/di.module';
import { CompLifeCycleComponent, ChildComponent } from './lifecycle/complifecycle.component';
import { ContactModule } from './multicomp/multicomp.module';
import { ServiceLoader } from './dynamic/serviceLoader';
import { DynamicComponent } from './dynamic/dynamic.component';
import { HTTPComponent } from './http/http.component';
import { WeatherComponent } from './http/weather.component';
import { routing } from './app.routing';
import { HomeComponent } from './home';
import { NotifyComponent } from './notify.component';
import { HiddenDirective } from './shared/Directives/hidden.directive';
import { TestComponent } from './shared/test.component';
import { HoverFocusDirective } from './shared/Directives/hoverfocus.component';
import { TemperaturePipe } from './shared/temperature.pipe';
import { LoginValidationComponent } from './Validation/login.component';
import { injectComponentFactoryResolver } from '@angular/core/src/render3';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    InvoiceComponent, 
    ViewChildParentComponent,
    ViewChildComponent,
    CompLifeCycleComponent, 
    ChildComponent,
    DynamicComponent, HTTPComponent, WeatherComponent,
    HomeComponent, NotifyComponent, 
    HiddenDirective, TestComponent, HoverFocusDirective,
    TemperaturePipe,
    LoginValidationComponent
  ],
  imports: [
    BrowserModule, FormsModule, BindingModule, IOModule, DIModule, ContactModule, HttpClientModule, ReactiveFormsModule,
    routing
  ],
  providers: [ServiceLoader],
  entryComponents: [DynamicComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
