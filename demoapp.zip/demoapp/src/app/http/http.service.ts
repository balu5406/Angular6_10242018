import { Injectable } from "@angular/core";

import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
}

@Injectable({ providedIn: 'root' })
export class HttpService{
    
    constructor(private httpCall: HttpClient){
        console.log("HTTP Service Injected");
    }

    base_url= 'http://localhost:3000';

    getFoods(): any {
        return this.httpCall.get(this.base_url + '/api/food').pipe( ( (data:any) => {
            console.log(data);
            return data;
        } ));
    }

    createFood(food){
        let reqBody = JSON.stringify(food);
        return this.httpCall.post(this.base_url + '/app/food', reqBody, httpOptions);
    }

    updateFood(food){
        let reqBody = JSON.stringify(food);
        return this.httpCall.put(this.base_url + '/app/food/', reqBody, httpOptions)
    }

    deleteFood(food){
        let reqBody = JSON.stringify(food);
        return this.httpCall.delete(this.base_url + '/app/food/' + food.id);
    }

}