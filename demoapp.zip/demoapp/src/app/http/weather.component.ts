import { Component } from "@angular/core";
import { FormControl } from '@angular/forms'

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { debounceTime, switchMap, map, debounce } from 'rxjs/operators';

const httpOptions = {
    headers: new HttpHeaders(
        { 'Content-Type': 'application/json' }
    )
};

@Component({
    selector: "app-weather",
    template: `
        <div class="container">
            <h3 style="background:orange">Live Weather Forecast by Murthy</h3>  
        
            City:<input type="text" [formControl]="srchInput">

            <h3>Current Temperature of City {{ srchInput }}, in {{ temprature }}F </h3>
            <h3>Humidity {{ humidity }}% </h3>
            <h3 >Status : {{ desc }}</h3>
        </div>
    `
})

export class WeatherComponent{
    private baseWeatherURL: string = 'http://api.openweathermap.org/data/2.5/weather?q=';
    private urlSuffix: string = "&units=imperial&appid=ca3f6d6ca3973a518834983d0b318f73";

    srchInput: FormControl = new FormControl();
    temprature: string;
    desc: string='';
    humidity: string='';

    constructor(private httpClnt: HttpClient){
        this.srchInput.valueChanges
            .pipe(debounceTime(4000))
            .pipe( switchMap( (city: string) => this.getWeatherInfo(city) ) )
            .subscribe( 
                (res: any) => {
                    this.desc = res.weather[0].description;
                    this.temprature = res.main.temp;
                    this.humidity = res.main.humidity;                    
                }, 
                (err: any) => {
                    console.log(`Can't get the weather, Error code: %s, URL: %s`, err.message, err.URL)
                },
                () => {
                    console.log("Done...");
                }
             );
    }
    ngOnInit(){
        this.srchInput.setValue("Hyderabad");
    }

    getWeatherInfo(city:string): Observable< Array<string> > {
        return this.httpClnt.get(this.baseWeatherURL + city + this.urlSuffix)
                    .pipe( map( (data:any) => {
                        console.log(data);
                        return data;
                    } ) )
    }

}