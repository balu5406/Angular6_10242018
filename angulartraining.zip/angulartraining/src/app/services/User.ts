export class User {
    constructor( public uname:string, public pwd:string ){
        
    }
}