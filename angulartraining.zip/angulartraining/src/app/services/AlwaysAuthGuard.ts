import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlwaysAuthGuard implements CanActivate {
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
        console.log("I am from AlwaysAuthGuard" + state);
        return true;
  }
}


/*

Intercepting before routing occurs with rules and roles:

The router supports the following kinds of guards:

There are four different types of Guards:
CanActivate
        - Checks to see if a user can visit a route.
CanActivateChild
        - Checks to see if a user can visit a routes children.
CanDeactivate
        -  Checks to see if a user can exit a route.
Resolve
   - Performs route data retrieval before route activation.
   (users Observerable/Promise)
CanLoad
    - Checks to see if a user can route to a module that
     lazy loaded.

In angular 5/6 , new guards are added which are
Useful for start/stop spinner when loading routes/modules or 
measure performance of guards

GuardCheckStart
ChildActivatorStart
ActivationStart
GuardCheckEnd, 
ResolveStart
ActivateEnd
ChildActivateEnd.

*/