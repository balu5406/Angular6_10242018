import { Component } from '@angular/core'
@Component({
  selector: 'dynamic-component',
  template: `<h3 style="text-align:center;background:pink">
  Email: dsrmurthysoftware@gmail.com
  </h3>`
})
export class DynamicComponent { }