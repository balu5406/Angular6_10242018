# Web Components with Angular 6 Elements

Built from a default Angular CLI setup

Commands:

* `npm run build && npm run package-elements` to create a build of a sample component
* `npm run serve` to run a http-server with example usage (click the button, watch the devtools console)

Read the complete walkthrough in the article: [Building Web Components with Angular Elements!](https://medium.com/@tomsu/building-web-components-with-angular-elements-746cd2a38d5b)
