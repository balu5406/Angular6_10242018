import {Injectable} from '@angular/core';

@Injectable()
export class HomeLoanService{
    serviceName:string;
    constructor(){
       this.serviceName='Home Loan Service';
       console.log(" I am home loan Service")
    }
    getDue(acno:number):number{
       return 20000;
    }
    getService(){
        return this.serviceName;
    }
}