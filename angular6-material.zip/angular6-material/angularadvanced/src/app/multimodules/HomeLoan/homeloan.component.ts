import {Component,OnInit} from '@angular/core';
import {HomeLoanService} from './homeloan.service';
@Component({
    selector:'app-homeloan',
      template:`
     <h1 class="well text-success">Hi! {{serviceName}}</h1>
    `
})
export class HomeLoanComponent implements OnInit{
    serviceName:string  | null;
    service:HomeLoanService| null;
    
    constructor(hls:HomeLoanService){
        this.service=hls;
    }    
    ngOnInit() {
      this.serviceName= this.service.getService();
    }
}