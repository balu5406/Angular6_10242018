import {Injectable} from '@angular/core';

@Injectable()
export class SavingsService{
    serviceName:string;
    constructor(){
       this.serviceName='Savings Account Service';
       console.log(" I am Savings Service");
    }
    getBalance(acno:number):number{
       return 5000;
    }
   getService(){
        return this.serviceName;
    }
}