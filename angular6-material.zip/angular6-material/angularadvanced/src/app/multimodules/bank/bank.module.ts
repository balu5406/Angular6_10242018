//Bank Facade
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {HomeLoanModule} from '../HomeLoan/homeloan.module';
import {SavingsModule} from '../Savings/savings.module';

import {BankComponent} from './bank.component';
@NgModule({
  imports: [
    CommonModule,
    HomeLoanModule,
    SavingsModule
  ],
  declarations: [BankComponent],
  exports:[BankComponent]
})
export class BankModule { }
