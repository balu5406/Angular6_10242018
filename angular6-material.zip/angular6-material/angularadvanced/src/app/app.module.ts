import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule} from '@angular/forms';
import {ReactiveFormsModule} from '@angular/forms'

import {HttpClientModule} from '@angular/common/http'
import {JsonpModule} from '@angular/http'

import { WeatherComponent } from './http/weather.component';
import {HttpComponent} from './http/http.component'

import { AppComponent } from './app.component';
import { MusicComponent } from './http/ITunes/music.component';

@NgModule({
  declarations: [
    AppComponent,WeatherComponent,HttpComponent,MusicComponent  ],
  imports: [
    BrowserModule, FormsModule,ReactiveFormsModule ,
    HttpClientModule,JsonpModule ],

  providers: [],  
  bootstrap: [AppComponent]
})
export class AppModule {
}
 
