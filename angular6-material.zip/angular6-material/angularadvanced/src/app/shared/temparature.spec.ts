import { TemperaturePipe } from './temperature.pipe';

describe('Testpipe ', () => {
  it('create an instance of pipe', () => {
    const pipe = new TemperaturePipe();
    expect(pipe).toBeTruthy();

    let result1= pipe.transform(40,'CtoF')
    expect(result1).toBeGreaterThan(40);

    let result2= pipe.transform(40,'FtoC')
    expect(result2).toBeLessThan(40);
    
  });
});