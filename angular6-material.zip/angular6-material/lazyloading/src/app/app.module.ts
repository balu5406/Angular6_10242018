import { NgModule,OnDestroy } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { routes } from './app-routing.module';

import AppComponent from './app.component';
import InlineComponent from './inline.component';
import { LoggingService } from './logging-service';

@NgModule({
  declarations: [
    AppComponent,
    InlineComponent
  ],
  imports: [ BrowserModule, routes ],
  bootstrap: [ AppComponent ],
  providers:[]
})
export class AppModule implements OnDestroy{
  /*
constructor(
    private _route: ActivatedRoute,
    private _userService: UserService
  ) {
    console.log('LazyUserModule launched!');
    this._route.paramMap.subscribe((params: ParamMap) => {
      // get the user from the route
      const user =  params.get('user');
      // set the user in the singleton UserService
      this._userService.set(user);
    });
  }

  LazyUserModule launched!
... move to different user: sriram ...
LazyUserModule destroyed!
... move to different user: kiran ...
'Error: The ng module LazyModule has already been destroyed.'
  */
  ngOnDestroy() {
    console.log('App Module  destroyed!');
  }
}
