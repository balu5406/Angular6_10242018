import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <section style="background:lightgrey">
  <div class="container text-center bg-danger"><h1>Code Splitting in Angular by Murthy</h1></div>
  <router-outlet></router-outlet>
</section>

<footer>
  <h3 class="container text-center bg-success">Copyright reserved to DSR Murthy</h3>
</footer>
    
  `
})
export default class AppComponent {}
