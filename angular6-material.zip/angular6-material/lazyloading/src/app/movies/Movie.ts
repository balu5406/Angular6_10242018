// This kind of data usually come via http via dataservice call

export interface IMovie{
    id:number;
    name:string;
    directorName:string;
    releaseYear:string;
}